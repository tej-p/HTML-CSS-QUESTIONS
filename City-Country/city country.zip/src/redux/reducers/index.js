// import { combineReducers } from "redux";
// import { cityReducer } from "./cityReducer";

// const reducer = combineReducers({
//     "allCities" : cityReducer ,
// })
// export default reducer;