export const ActionTypes = {
    SET_CITIES : "SET_CITIES",
    SELECTED_CITIES : "SELECTED_CITIES"
}